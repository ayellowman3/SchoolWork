/*
George Huang
12/9/16
IT 206-001
Assignment 10

Ordering System is a program that allow Monica's company to store order information
for her company. This program stores customer information, handling instructions,
and other information related to the type of orders they are storing. The types of
orders are internet order, phone order, and mail order. 

The reason users chooses the order types before instead of during the program is because
the employee should know the type of order they are inputing
input

Menu choice
1: Add Internet Order
2: Add Mail Order
3: Add Phone Order
4: Print summary
5: Exit Program

Variable: name
type: String
description: Customer name

Variable: phone number
type: String 
description: Customer's phone number

Variable: company name
type: String
description: the name of the company 

Variable: Handling instruction
type: int
description: Handling instruction selected from a list 

Variable: Password
type: String
description: password for internet order 

Variable: email
type: String
description:  email for internet order

Variable: Status
type: StatusUpdate
description: Array of statuses for shipping

Variable: call back number
type: String
description: call back phone number 

Variable: call back time
type: String
description: best time to call back
*/
import javax.swing.JOptionPane;

public class OrderingSystem{
   public static void main(String[] args){
   	//array of orders
      Orders[] order = new Orders[Orders.MAX_NUM_ORDERS];
      int menuOption;
      do{
      	//get menu options
         menuOption = getMenuOption();
         switch(menuOption){
            case 5:
               break;
            case 1:
               addOrder(order, Orders.getOrderCount(), 0);
               break;
            case 2:
               addOrder(order, Orders.getOrderCount(), 1);
               break;
            case 3:
               addOrder(order, Orders.getOrderCount(), 2);
               break;
            case 4:
               printSummery(order, Orders.getOrderCount());
               break;
         }
      }while(menuOption != 5);
      printSummery(order, Orders.getOrderCount());
   }

	//get user input for menu option
   public static int getMenuOption(){
      int menuOption;
      menuOption = getInt("Select menu option\n\n[1] Enter internet order\n[2] Enter mail order\n[3] Enter phone order\n[4] Print summery\n[5] Exit", "Error! Invalid menu option selected", 1, 5);
      return menuOption;
   }

	//gets user information for orders
   public static void addOrder(Orders[] order, int count, int orderType){
      if(count<Orders.MAX_NUM_ORDERS){
      	//gets customer object information
         Customer customer = getCustomer();
      	//gets user input for handling instruction
         int handlingInstruction = getInt(getListMessage("Select handling instruction: \n\n", Orders.VALID_HANDLING_INSTRUCTION), "Error! handling instruction entered is invalid!",  Orders.MIN_HANDLING_NUM, Orders.MAX_HANDLING_NUM) - 1;
      	//get input for internet orders
         if(orderType == 0){
         	//get user input for password
            String password = getPassword("Enter password\n*one upper case and one lower case character is required", "Error! Invalid password entered!");
         	//get user input for email
            String email = getEmail("Enter email address: \nexample: email@domain.com", "Error! Invalid email entered!");
            int statusCount = 0;
            StatusUpdate[] stat = new StatusUpdate[Internet.MAX_NUM_STATUS_UPDATES];
            if(JOptionPane.showConfirmDialog(null, "Would you like to enter any status updates?") == JOptionPane.YES_OPTION){
               do{
               	//get employee name for status
                  String employeeName = getString("Enter customer service representive's name","Error! Invalid customer service representive name entered!");
               	//get status input from a list
                  int status = getInt(getListMessage("Select shipping status: \n\n", StatusUpdate.VALID_STATUS), "Error! Invalid status entered!" , StatusUpdate.MIN_STATUS_NUM, StatusUpdate.MAX_STATUS_NUM) - 1;
                  stat[statusCount] = new StatusUpdate(employeeName, status);
                  statusCount++;
               }while(statusCount < Internet.MAX_NUM_STATUS_UPDATES && JOptionPane.showConfirmDialog(null, "Would you like to enter any more status updates?") == JOptionPane.YES_OPTION);
            }
            int numericCode;
            if(JOptionPane.showConfirmDialog(null, "Would you like to enter a numeric code?") == JOptionPane.YES_OPTION){
            	//get numeric code input
               numericCode = getInt("Enter numeric code", "Error! Invalid numeric code entered!", Internet.MIN_NUMERIC_CODE, Internet.MAX_NUMERIC_CODE);
               order[count] = new Internet(customer, handlingInstruction, password, email, stat, statusCount, true, numericCode);
            }
            else{
               order[count] = new Internet(customer, handlingInstruction, password, email, stat, statusCount);
            }
         }
         //get input for mail orders
         else if(orderType == 1){
            order[count] = new Mail(customer, handlingInstruction);
         }
         //get input for phone orders
         else{
            String callbackNumber;
         	//ask if callback number is the same as phone number
            if(JOptionPane.showConfirmDialog(null, "Is your call back number the same\nas your phone number") == JOptionPane.YES_OPTION){
               callbackNumber = customer.getPhoneNumber();
            }
            else{
            	//get user input for call back number
               callbackNumber = getPhoneNumber("Enter customer's call back number:\nexample:(xxx) xxx-xxxx", "Error! Invalid phone number entered!");
            }
            String callbackTime;
         	//get user input for call back time
            int callbackTimeInt = JOptionPane.showOptionDialog(null, "When is the best call back time?", "Call back time", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, Phone.CALL_TIME, Phone.CALL_TIME[0]);
            callbackTime = Phone.CALL_TIME_STR[callbackTimeInt];
            order[count] = new Phone(customer, handlingInstruction, callbackNumber, callbackTime);
         }
      }
      else{
         JOptionPane.showMessageDialog(null, "Maximum number of orders entered!");
      }
   }

	//method to get customer information
   public static Customer getCustomer(){
      Customer customer;
      String name = getString("Enter customer name: ", "Error! Customer name entered is invalid!");
      String phoneNumber = getPhoneNumber("Enter phone number: \nexample:(xxx) xxx-xxxx", "Error! Phone number entered is invalid!");
      boolean company = JOptionPane.showConfirmDialog(null, "Would you like to enter a company name?") == JOptionPane.YES_OPTION;
      if(company){
         String companyName = getString("Enter company name: ", "Error! Company name entered is invalid!");
         customer = new Customer(name, phoneNumber, company, companyName);	
      }
      else{
         customer = new Customer(name, phoneNumber);
      }
      return customer;
   
   }

	//method to get integer input
   public static int getInt(String message, String error, int min, int max){
      int num;
      do{
         try{
            num = Integer.parseInt(JOptionPane.showInputDialog(message));
         }
         catch(NumberFormatException e){
            num = -1;
         }
         if(num < min || num > max){JOptionPane.showMessageDialog(null, error);}
      }while(num < min || num > max);
      return num;
   }

	//method to get phone number
   public static String getPhoneNumber(String message, String error){
      String phoneNumber;
      boolean valid;
      do{
         phoneNumber = getString(message, error);
         valid = Customer.validatePhoneNumber(phoneNumber);
         if(!valid){JOptionPane.showMessageDialog(null, error);}
      }while(!valid);
      return phoneNumber;
   }

	//method to get string input
   public static String getString(String message, String error){
      String str;
      do{
         str = JOptionPane.showInputDialog(message);
         if(str.equals("")){JOptionPane.showMessageDialog(null, error);}
      }while(str.equals(""));
      return str;
   }

	//method to get password
   public static String getPassword(String message, String error){
      String password;
      boolean valid;
      do{
         password = getString(message, error);
         valid = Internet.validatePassword(password);
         if(!valid){JOptionPane.showMessageDialog(null, error);}
      }while(!valid);
      return password;
   }

	//method to get email
   public static String getEmail(String message, String error){
      String email;
      boolean valid;
      do{
         email = getString(message, error);
         valid = Internet.validateEmail(email);
         if(!valid){JOptionPane.showMessageDialog(null, error);}
      }while(!valid);
      return email;
   }

	//method to get a list from an array
   public static String getListMessage(String str, String[] list){
      String message = str;
      for(int i = 0; i < list.length; i++){
         message += "  [" + (i + 1) + "] " + list[i] + "\n";
      }
      return message;
   }

	//method to get summery of the input
   public static void printSummery(Orders[] order, int count){
      String message = "Order summary\n\n";
      int[] orderCount;
      if(count>0){
         for(int i = 0; i < count; i++){
            message += order[i].toString() + "\n\n";
         }
         orderCount = countOrders(order, count);
         message += "Internet Orders: " + orderCount[0]
            +"\nMail Orders: " + orderCount[1]
            +"\nPhone Orders: " + orderCount[2]
            +"\nTotal Orders: " + orderCount[3];
      }
      else{
         message = "No orders have been entered!";
      }
      JOptionPane.showMessageDialog(null, message);
   }

	//method to count orders
   public static int[] countOrders(Orders[] order, int count){
      int[] orderCount = {0, 0, 0, 0}; 
      for(int i = 0; i < count; i++){
         boolean notEmpty = true;
         try{
            if(order[i]==null){
               throw new NullPointerException();
            }
         }
         catch(NullPointerException e){
            notEmpty = false;
         }
         if(notEmpty){
            orderCount[3]++;
            if(order[i] instanceof Internet){
               orderCount[0]++;
            }
            else if(order[i] instanceof Mail){
               orderCount[1]++;
            }
            else{
               orderCount[2]++;
            }
         }
      }
      return orderCount;
   }
}