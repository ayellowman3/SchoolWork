//child class or Orders
public class Mail extends Orders{
	
   public Mail(Customer customerInfo, int handlingInstruction){
      super(customerInfo, handlingInstruction);
   }

   public String toString(){
      return super.toString();
   }
}