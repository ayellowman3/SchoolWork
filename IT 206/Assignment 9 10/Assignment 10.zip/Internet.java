//child class of orders
public class Internet extends Orders{
	//constants
   public static final int MAX_NUM_STATUS_UPDATES = 17;
   public static final int MIN_NUMERIC_CODE = 0;
   public static final int MAX_NUMERIC_CODE = 47;
   public static final int MIN_PASSWORD_LENGTH = 6;

	//variables
   private String password;
   private String email;
   private StatusUpdate[] stat;
   private int statusCount;
   private boolean code;
   private int numericCode;

	//constructors
   public Internet(Customer customerInfo, int handlingInstruction, String password, String email, StatusUpdate[] stat, int statusCount){
      super(customerInfo, handlingInstruction);
      this.password = password;
      this.email = email;
      this.stat = new StatusUpdate[statusCount];
      for(int i = 0; i<statusCount; i++){
         this.stat[i] = stat[i];
      }
      this.statusCount = statusCount;
   }

   public Internet(Customer customerInfo, int handlingInstruction, String password, String email, StatusUpdate[] stat, int statusCount, boolean code, int numericCode){
      super(customerInfo, handlingInstruction);
      this.password = password;
      this.email = email;
      this.stat = stat;
      this.statusCount = statusCount;
      this.code = code;
      this.numericCode = numericCode;		
   }

	//accessors
   public String getPassword(){
      return password;
   }

   public String getEmail(){
      return email;
   }

   public StatusUpdate[] getStatusUpdate(){
      return stat;
   }

   public String getStatusList(){
      String list = "";
      if(statusCount > 0){
         for(int i = 0; i < statusCount; i++){
            list += stat[i].toString();
         }
      }
      return list;
   }

   public int getNumericCode(){
      return numericCode;
   }

	//mutators

   public boolean setPassword(String password){
      if(validatePassword(password)){
         this.password = password;
         return true;
      }
      return false;
   }

   public boolean setEmail(String email){
      if(validateEmail(email)){
         this.email = email;
         return true;
      }
      return false;
   }

   public void setStatus(StatusUpdate[] stat, int statusCount){
      this.stat = stat;
      this.statusCount = statusCount;
   }

		//add numeric code
   public boolean setNumericCode(boolean code, int numericCode){
      this.code = code;
      this.numericCode = numericCode;
      return true;
   }
		
		//remove numeric code
   public boolean setNumericCode(boolean code){
      this.code = code;
      return true;
   }
		
	//validator
   public static boolean validatePassword(String password){
      if(password.length() < MIN_PASSWORD_LENGTH){
         return false;
      }
      if(password.charAt(0) == ' '){
         return false;
      }
      if(password.charAt(password.length()-1) == ' '){
         return false;
      }
      boolean uppercase = false;
      boolean lowercase = false;
      for(int i = 0; i < password.length(); i++){
         if(Character.isUpperCase(password.charAt(i))){uppercase = true;}
         if(Character.isLowerCase(password.charAt(i))){lowercase = true;}
      }
      return(uppercase&&lowercase);
   }

   public static boolean validateEmail(String email){
      if(email.length()<6){
         return false;
      }
      int atCount = 0;
      int atLocation = 0;
      for(int i = 0; i < email.length(); i++){
         if(email.charAt(i) == '@'){
            atCount++;
            atLocation = i;
         }
      }
      if(atCount != 1){
         return false;
      }
      if(atLocation == 0 || atLocation == email.length()-1){
         return false;
      }
      if(email.charAt(atLocation+1) == '.' || email.charAt(atLocation-1)== '.' || email.charAt(0)== '.'){
         return false;
      }
      String part1 = email.substring(0, atLocation);
      String part2 = email.substring(atLocation + 1);
      for(int i = 0; i < part1.length(); i++){
         if(part1.charAt(i) == ' '){
            return false;
         }
      }
      int periodCount = 0;
      int lastPeriod = 0;
      for(int i = 0; i < part2.length(); i++){
         if(part2.charAt(i) == ' '){
            return false;
         }
         if(part2.charAt(i) == '.'){
            periodCount++;
            lastPeriod = i;
         }
      }
      if(periodCount == 0){
         return false;
      }
      if(part2.charAt(0) == '.'){
         return false;
      }
      int charAfterPeriod = part2.length() - lastPeriod - 1;
      if(charAfterPeriod < 2 || charAfterPeriod > 4){
         return false;
      }
      return true;
   }


	//special purpose method
   public String toString(){
      String str = super.toString() + "\nPassword: " + password + "\nEmail: " + email;
      if(statusCount>0){
         str += "\nStatus:";
         for(int i = 0; i < statusCount; i++){
            str += stat[i].toString();
         }
      }
      if(code){str+="\nNumeric code: " + numericCode;}
      return str;
   }
}