//Customer class aggregation relationship with Orders
public class Customer{
	
	//variables
   private String name;
   private String phoneNumber;
   private boolean company;
   private String companyName;

	//constructor
   public Customer(String name, String phoneNumber){
      this.name = name;
      this.phoneNumber = phoneNumber;
   }

   public Customer(String name, String phoneNumber, boolean company, String companyName){
      this.name = name;
      this.phoneNumber = phoneNumber;
      this.company = company;
      this.companyName = companyName;
   }

	//accessor
   public String getName(){
      return name;
   }

   public String getPhoneNumber(){
      return phoneNumber;
   }

   public String getCompanyName(){
      return companyName;
   }

	//mutator
   public boolean setName(String name){
      if(validateString(name)){
         this.name = name;
         return true;
      }
      return false;
   }

   public boolean setPhoneNumber(String phoneNumber){
      if(validatePhoneNumber(phoneNumber)){
         this.phoneNumber = phoneNumber;
         return true;
      }
      return false;
   }

   public boolean setCompanyName(String companyName){
      if(validateString(companyName)){
         this.companyName = companyName;
         return true;
      }
      return false;
   }


	//validator
   public static boolean validateString(String str){
      return(!str.equals(""));
   }

   public static boolean validatePhoneNumber(String phoneNumber){
      int[] numPosition = new int[] {1,2,3,6,7,8,10,11,12,13};
      if(phoneNumber.length()!= 14){
         return false;
      }
      if(phoneNumber.charAt(0) != '('){
         return false;
      }
      if(phoneNumber.charAt(4) != ')'){
         return false;
      }
      if(phoneNumber.charAt(5) != ' '){
         return false;
      }
      if(phoneNumber.charAt(9) != '-'){
         return false;
      }
      for(int i = 0; i < 10; i++){
         if(!Character.isDigit(phoneNumber.charAt(numPosition[i]))){
            return false;
         }
      }
      return true;
   }

	//special purpose method
   public String toString(){
      String str = "\nName: " + name + "\nPhone Number: " + phoneNumber;
      if(company){
         str+="\nCompany Name: " + companyName;
      }
      return str;
   }
}