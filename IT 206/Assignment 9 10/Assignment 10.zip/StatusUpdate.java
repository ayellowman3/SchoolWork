//status update class with a composition relationship with orders
public class StatusUpdate{

	//Constants
   public static final String[] VALID_STATUS = {"Order received", "Preparing Shipment", "Ready for Pick up", "Shipment Processing", "Arrived at facility", "Depart facility", "Out for delivery"};
   public static final int MIN_STATUS_NUM = 1;
   public static final int MAX_STATUS_NUM = 7;


	//Variables
   private String employeeName;
   private int status;

	//constructor
   public StatusUpdate(String employeeName, int status){
      this.employeeName = employeeName;
      this.status = status;
   }

	//Accessor
   public String getEmployeeName(){
      return employeeName;
   }

   public String getStatus(){
      return VALID_STATUS[status];
   }

	//Mutator
   public boolean setEmployeeName(String name){
      if(validateEmployeeName(name)){
         this.employeeName = name;
         return true;
      }
      return false;
   }

   public boolean setStatus(int status){
      if(validateStatus(status)){
         this.status = status - 1;
         return true;
      }
      return false;
   }
	
	//Validator
   public boolean validateEmployeeName(String name){
      return(!name.equals(""));
   }

   public boolean validateStatus(int status){
      return (status >= MIN_STATUS_NUM && status <= MAX_STATUS_NUM);
   }


	//Special Purpose method
   public String toString(){
      return "\n   Employee Name: " + employeeName + "\n   Status: " + VALID_STATUS[status];
   }
}