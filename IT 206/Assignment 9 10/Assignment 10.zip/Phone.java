//child class of orders
public class Phone extends Orders{
	//constants
   public static final Object[] CALL_TIME = {"Morning", "Afternoon", "Evening"};
   public static final String[] CALL_TIME_STR = {"Morning", "Afternoon", "Evening"};

	//variables
   private String callbackNumber;
   private String callbackTime;

	//constructor
   public Phone(Customer customerInfo, int handlingInstruction, String callbackNumber, String callbackTime){
      super(customerInfo, handlingInstruction);
      this.callbackNumber = callbackNumber;
      this.callbackTime = callbackTime;
   }

	//accessor
   public String getCallbackNumber(){
      return callbackNumber;
   }

   public String getCallbackTime(){
      return callbackTime;
   }

	//mutator
   public boolean setCallbackNumber(String phoneNumber){
      if(validatePhoneNumber(phoneNumber)){
         this.callbackNumber = phoneNumber;
         return true;
      }
      return false;
   }

   public boolean setCallbackTime(){
      return false;
   }
	
	//validator
   public static boolean validatePhoneNumber(String phoneNumber){
      int[] numPosition = new int[] {1,2,3,6,7,8,10,11,12,13};
      if(phoneNumber.length()!= 14){
         return false;
      }
      if(phoneNumber.charAt(0) != '('){
         return false;
      }
      if(phoneNumber.charAt(4) != ')'){
         return false;
      }
      if(phoneNumber.charAt(5) != ' '){
         return false;
      }
      if(phoneNumber.charAt(9) != '-'){
         return false;
      }
      for(int i = 0; i < 10; i++){
         if(!Character.isDigit(phoneNumber.charAt(numPosition[i]))){
            return false;
         }
      }
      return true;
   }
	//special purpose method
   public String toString(){
      String str = super.toString();
      str += "\nCallback number: " + callbackNumber
         + "\nCallback time: " + callbackTime;
      return str;
   }
}