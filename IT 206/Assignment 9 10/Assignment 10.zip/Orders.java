//Object class for orders

public abstract class Orders{
	//constants
   public static final int MAX_NUM_ORDERS = 216;
   public static final int ORDER_ID_START = 1000;
   public static final String[] VALID_HANDLING_INSTRUCTION ={"Leave at front door", "Leave at side door", "Leave at backdoor", "Leave at front desk", "Handle with care", "Draw a pikachu"};
   public static final int MIN_HANDLING_NUM = 1;
   public static final int MAX_HANDLING_NUM = 6;

	//variables
   private static int orderCount = 0;
   private static int lastOrderNumber = ORDER_ID_START;
   private int orderNumber;
   private Customer customerInfo;
   private int handlingInstruction;

   public Orders(Customer customerInfo, int handlingInstruction){
      this.orderNumber = lastOrderNumber + 1;
      Orders.lastOrderNumber = orderNumber;
      this.customerInfo = customerInfo;
      this.handlingInstruction = handlingInstruction;
      orderCount++;
   }

	//accessor
   public static int getOrderCount(){
      return orderCount;
   }

   public int getOrderNumber(){
      return orderNumber;
   }

   public String getName(){
      return customerInfo.getName();
   }

   public String getPhoneNumber(){
      return customerInfo.getPhoneNumber();
   }

   public String getCompanyName(){
      return customerInfo.getCompanyName();
   }

   public String getHandlingInstruction(){
      return VALID_HANDLING_INSTRUCTION[handlingInstruction];
   }

	//mutator
   public void setCustomer(Customer customerInfo){
      this.customerInfo = customerInfo;
   }

   public boolean setName(String name){
      return(customerInfo.setName(name));
   }

   public boolean setPhoneNumber(String phoneNumber){
      return(customerInfo.setPhoneNumber(phoneNumber));
   }

   public boolean setCompanyName(String companyName){
      return(customerInfo.setCompanyName(companyName));
   }

   public boolean setHandlingInstruction(String handlingInstruction){
      return true;
   }

	//validator

	


	//special purpose method
   public String toString(){
      String str = "Order Number: " + orderNumber;
      str += customerInfo.toString() + "\nHandling Instruction: " + VALID_HANDLING_INSTRUCTION[handlingInstruction];
      return str;
   }
}