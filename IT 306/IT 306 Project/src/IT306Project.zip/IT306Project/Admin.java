
public class Admin extends Employee{

    public Admin(){
        super();
    }

    public Admin(String userID, String fName, String lName, String username, String password, String email, String address, String resource){
        super(userID, fName, lName, username, password, email, address, resource);
    }
}
