
public class Employee extends User{
    public Employee(){
        super();
    }

    public Employee(String userID, String fName, String lName, String username, String password, String email, String address, String resource){
        super(userID, fName, lName, username, password, email, address, resource);
    }
}
