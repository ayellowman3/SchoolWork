
class ResourceCategory {

}
