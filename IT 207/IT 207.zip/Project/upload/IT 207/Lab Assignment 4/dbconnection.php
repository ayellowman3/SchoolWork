<?php
	$host = "helios.ite.gmu.edu";
	$user = "ghuang3";
	$password = "fuphuz";

	$database = "ghuang3";
	$table = "COMMENTS";

	$connection = mysqli_connect($host, $user, $password);
	mysqli_select_db($connection, $database);
?>