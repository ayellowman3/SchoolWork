<?php
echo
"<h3>Huh?</h3><br>
Kirschner and Karpinski report that:<br>
Students who used social networking shites while studying scored 20% lower on tests and students who used social media had an average<br>
GPA of 3.06 bersus non-users who had an average GPA of 3.82.<br>
Sourse: Paul A. Kirschner and Aryn C. Karpinski. \"Facebook and Academic Performance.\" Computers in Human Behavior, Nov.2010";
?>