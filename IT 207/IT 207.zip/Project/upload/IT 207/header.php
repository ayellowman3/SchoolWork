<header>
<strong>Applied IT Programming, IT 207 003, Fall 2016</strong><br />
Jaswanth Padigala<br />
George Mason University<br />
<strong>George Huang</strong><br />
<a href="mailto:ghuang3@gmu.edu">ghuang3@masonlive.gmu.edu</a><br />
<?php 
date_default_timezone_set("America/New_York");
print( date("G:i M d, Y T.", getlastmod()));?>
</header>